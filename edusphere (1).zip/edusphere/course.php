<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.html");
    exit();
}

$conn = new mysqli("localhost", "root", "Shiva6j2", "edusphere");

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Invalid course ID";
    exit();
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM courses WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "Course not found";
    exit();
}

$course = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlspecialchars($course['title']); ?> - Course</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f4f6f8;
      margin: 0;
      padding: 0;
    }
    header {
      background-color: #3f51b5;
      color: white;
      padding: 1.5rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .back {
      color: white;
      text-decoration: none;
      background-color: #ff9800;
      padding: 0.5rem 1rem;
      border-radius: 5px;
      transition: 0.3s;
    }
    .back:hover {
      background-color: #e68900;
    }
    .container {
      max-width: 1000px;
      margin: 2rem auto;
      background: white;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    h2 {
      color: #3f51b5;
      margin-top: 0;
    }
    .info {
      color: #555;
      margin-bottom: 1.5rem;
    }
    iframe {
      width: 100%;
      height: 500px;
      border: none;
      border-radius: 8px;
      margin-top: 1rem;
    }
  </style>
</head>
<body>
  <header>
    <h2><?php echo htmlspecialchars($course['title']); ?></h2>
    <a href="dashboard.php" class="back">← Back to Dashboard</a>
  </header>

  <div class="container">
    <p class="info"><strong>Instructor:</strong> <?php echo htmlspecialchars($course['instructor']); ?></p>
    <p class="info"><strong>Duration:</strong> <?php echo htmlspecialchars($course['duration']); ?></p>
    <p><?php echo htmlspecialchars($course['description']); ?></p>

    <?php if (!empty($course['video_url'])): ?>
      <iframe src="<?php echo htmlspecialchars($course['video_url']); ?>" allowfullscreen></iframe>
    <?php else: ?>
      <p>No video available for this course.</p>
    <?php endif; ?>
  </div>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.html");
    exit();
}

$conn = new mysqli("localhost", "root", "Shiva6j2", "edusphere");
$result = $conn->query("SELECT id, title, description FROM courses");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>EduSphere Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
    }
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      background: #f4f6f8;
    }
    header {
      background-color: #3f51b5;
      color: white;
      padding: 1.5rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    header h1 {
      margin: 0;
      font-size: 24px;
    }
    .logout {
      color: white;
      text-decoration: none;
      background-color: #ff4081;
      padding: 0.5rem 1rem;
      border-radius: 5px;
      transition: 0.3s;
    }
    .logout:hover {
      background-color: #f50057;
    }
    .course-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 1.5rem;
      padding: 2rem;
      max-width: 1200px;
      margin: auto;
    }
    .card {
      background: white;
      border-radius: 10px;
      padding: 1.5rem;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      text-decoration: none;
      color: #333;
      transition: transform 0.2s ease, box-shadow 0.3s;
    }
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.15);
    }
    .card h3 {
      margin-top: 0;
      font-size: 20px;
      color: #3f51b5;
    }
    .card p {
      color: #666;
    }
  </style>
</head>
<body>
  <header>
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['user']); ?> 👋</h1>
    <a href="logout.php" class="logout">Logout</a>
  </header>
  <div class="course-container">
    <?php while ($row = $result->fetch_assoc()) { ?>
      <a href="course.php?id=<?php echo $row['id']; ?>" class="card">
        <h3><?php echo htmlspecialchars($row['title']); ?></h3>
        <p><?php echo htmlspecialchars(substr($row['description'], 0, 100)) . '...'; ?></p>
      </a>
    <?php } ?>
  </div>
</body>
</html>

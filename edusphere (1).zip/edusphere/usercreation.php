<?php
$conn = new mysqli("localhost", "root", "Shiva6j2", "edusphere");

// Check for existing username
$username = 'admin'; // or get this from input

$result = $conn->query("SELECT * FROM users WHERE username = '$username'");
if ($result->num_rows > 0) {
    echo "User already exists!";
} else {
    // If user doesn't exist, insert the new user
    $password = password_hash("admin123", PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (username, password) VALUES ('$username', '$password')");
    echo "User created!";
}
?>

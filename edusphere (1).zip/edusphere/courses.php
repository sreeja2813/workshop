<?php
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "Shiva6j2", "edusphere");

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// SQL query
$sql = "SELECT title, description FROM courses";
$result = $conn->query($sql);

// Response array
$courses = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $courses[] = $row;
    }
}

echo json_encode($courses);
?>
